<template>
 <nav>
   <router-link to="/">HOME</router-link>router-link>
   </nav>
    <router-view />
</template>>
     