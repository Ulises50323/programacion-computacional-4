import { createRouter, createWebHashHistory } from "vue-router";
import Home from './src/views/home.vue'

export default createRouter({
    history:createWebHashHistory(),
    routes:[
        {
            path:'/',
            name: 'Home',
            component:Home
        } ,{

        }
    ],
})