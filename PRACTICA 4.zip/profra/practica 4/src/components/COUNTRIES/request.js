const BASE_URL = "https://restcountries.com"
const createURL = (path)=> new URL(path, BASE_URL);

const getallcoutries = createURL("/v3.1/all");
const getbyRegion =
(RegionName) => createURL(`/v3.1/regin${RegionName}`);

export default{
    BASE_URL,
    getallcoutries,
    getbyRegion

};