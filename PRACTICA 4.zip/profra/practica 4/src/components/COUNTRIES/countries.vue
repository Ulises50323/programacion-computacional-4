<template>


</template>

<script>

import requests from './requests';

export default {
data(){
    return{

        data: [],
    }



},
methods: {

    async getAllcountries(){

        const response = fetch(rrequest.getALLcountries);
        this.data = await response.json();
    }
}


}

</script>